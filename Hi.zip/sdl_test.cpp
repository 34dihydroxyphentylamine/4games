#include <SDL.h>
#include <iostream>
#include <cmath>          
#include <cstdlib>     
#include <ctime>         
#include <algorithm>     

const int WINDOW_WIDTH = 800;
const int WINDOW_HEIGHT = 600;

const int BALL_DIAMETER = 30;
const int BALL_RADIUS = BALL_DIAMETER / 2;
const float INITIAL_BALL_SPEED = 4.0f;        
float current_ball_speed = INITIAL_BALL_SPEED;
const float BALL_BOOST_FACTOR = 1.2f;            
const int BALL_BOOST_DURATION_FRAMES = 30;              
int ball_boost_timer = 0;        

const int PADDLE_WIDTH = 20;
const int PADDLE_HEIGHT = 100;
const float PADDLE_SPEED = 6.0f;       

float ball_x = WINDOW_WIDTH / 2.0f;
float ball_y = WINDOW_HEIGHT / 2.0f;

float ball_dx = 0.0f;   
float ball_dy = 0.0f;   

SDL_Rect leftPaddle = {
    0,       
    (WINDOW_HEIGHT - PADDLE_HEIGHT) / 2,     
    PADDLE_WIDTH,
    PADDLE_HEIGHT
};

SDL_Rect rightPaddle = {
    WINDOW_WIDTH - PADDLE_WIDTH,       
    (WINDOW_HEIGHT - PADDLE_HEIGHT) / 2,     
    PADDLE_WIDTH,
    PADDLE_HEIGHT
};

void drawFilledCircle(SDL_Renderer* renderer, int centerX, int centerY, int radius, Uint8 r, Uint8 g, Uint8 b, Uint8 a) {
    SDL_SetRenderDrawColor(renderer, r, g, b, a);
    for (int y = -radius; y <= radius; y++) {
        int x = static_cast<int>(sqrt(static_cast<float>(radius * radius - y * y)));
        SDL_RenderDrawLine(renderer, centerX - x, centerY + y, centerX + x, centerY + y);
    }
}

bool checkCollision(float ballX, float ballY, int ballRadius, const SDL_Rect& rect) {
    float closestX = std::max(static_cast<float>(rect.x), std::min(ballX, static_cast<float>(rect.x + rect.w)));
    float closestY = std::max(static_cast<float>(rect.y), std::min(ballY, static_cast<float>(rect.y + rect.h)));

    float distanceX = ballX - closestX;
    float distanceY = ballY - closestY;

    return (distanceX * distanceX + distanceY * distanceY) < (ballRadius * ballRadius);
}


int main(int argc, char* args[]) {
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        std::cerr << "SDL could not initialize! SDL_Error: " << SDL_GetError() << std::endl;
        return 1;
    }

    srand(static_cast<unsigned int>(time(0)));

    SDL_Window* window = SDL_CreateWindow(
        "Pong Clone with Bouncing Ball",
        SDL_WINDOWPOS_UNDEFINED,
        SDL_WINDOWPOS_UNDEFINED,
        WINDOW_WIDTH,
        WINDOW_HEIGHT,
        SDL_WINDOW_SHOWN
    );
    if (window == nullptr) {
        std::cerr << "Window could not be created! SDL_Error: " << SDL_GetError() << std::endl;
        SDL_Quit();
        return 1;
    }

    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (renderer == nullptr) {
        std::cerr << "Renderer could not be created! SDL_Error: " << SDL_GetError() << std::endl;
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 1;
    }

    bool quit = false;
    SDL_Event e;

    while (!quit) {
        while (SDL_PollEvent(&e) != 0) {
            if (e.type == SDL_QUIT) {
                quit = true;
            }
            else if (e.type == SDL_MOUSEBUTTONDOWN) {
                int mouseX = e.button.x;
                int mouseY = e.button.y;

                float distance = sqrt(pow(mouseX - ball_x, 2) + pow(mouseY - ball_y, 2));

                if (distance <= BALL_RADIUS) {
                    float angle;
                    do {
                        angle = static_cast<float>(rand()) / static_cast<float>(RAND_MAX) * 2.0f * M_PI;
                    } while (std::abs(std::sin(angle)) > 0.9f || std::abs(std::cos(angle)) < 0.2f);

                    ball_dx = cos(angle);
                    ball_dy = sin(angle);

                    if (std::abs(ball_dx) < 0.1f && std::abs(ball_dy) < 0.1f) {
                        ball_dx = 1.0f;    
                        ball_dy = 0.5f;
                    }
                    float magnitude = sqrt(ball_dx * ball_dx + ball_dy * ball_dy);
                    if (magnitude != 0) {     
                        ball_dx /= magnitude;
                        ball_dy /= magnitude;
                    }

                    current_ball_speed = INITIAL_BALL_SPEED;     
                    ball_boost_timer = 0;     
                }
            }
        }

        const Uint8* currentKeyStates = SDL_GetKeyboardState(NULL);

        if (currentKeyStates[SDL_SCANCODE_W]) {
            leftPaddle.y -= PADDLE_SPEED;
        }
        if (currentKeyStates[SDL_SCANCODE_S]) {
            leftPaddle.y += PADDLE_SPEED;
        }

        if (currentKeyStates[SDL_SCANCODE_UP]) {
            rightPaddle.y -= PADDLE_SPEED;
        }
        if (currentKeyStates[SDL_SCANCODE_DOWN]) {
            rightPaddle.y += PADDLE_SPEED;
        }

        if (leftPaddle.y < 0) leftPaddle.y = 0;
        if (leftPaddle.y + PADDLE_HEIGHT > WINDOW_HEIGHT) leftPaddle.y = WINDOW_HEIGHT - PADDLE_HEIGHT;

        if (rightPaddle.y < 0) rightPaddle.y = 0;
        if (rightPaddle.y + PADDLE_HEIGHT > WINDOW_HEIGHT) rightPaddle.y = WINDOW_HEIGHT - PADDLE_HEIGHT;

        ball_x += ball_dx * current_ball_speed;
        ball_y += ball_dy * current_ball_speed;

        bool reflected_this_frame = false;

        if (ball_y + BALL_RADIUS > WINDOW_HEIGHT) {
            ball_y = WINDOW_HEIGHT - BALL_RADIUS;    
            ball_dy = -std::abs(ball_dy);    
            reflected_this_frame = true;
        }
        else if (ball_y - BALL_RADIUS < 0) {
            ball_y = BALL_RADIUS;    
            ball_dy = std::abs(ball_dy);    
            reflected_this_frame = true;
        }

        if (ball_dx < 0 && checkCollision(ball_x, ball_y, BALL_RADIUS, leftPaddle)) {
            ball_x = leftPaddle.x + PADDLE_WIDTH + BALL_RADIUS;         
            ball_dx = std::abs(ball_dx);          
            reflected_this_frame = true;
        }

        if (ball_dx > 0 && checkCollision(ball_x, ball_y, BALL_RADIUS, rightPaddle)) {
            ball_x = rightPaddle.x - BALL_RADIUS;         
            ball_dx = -std::abs(ball_dx);          
            reflected_this_frame = true;
        }

        if (ball_x - BALL_RADIUS < 0) {     
            ball_x = BALL_RADIUS;
            ball_dx = std::abs(ball_dx);     
            reflected_this_frame = true;
        }
        else if (ball_x + BALL_RADIUS > WINDOW_WIDTH) {     
            ball_x = WINDOW_WIDTH - BALL_RADIUS;
            ball_dx = -std::abs(ball_dx);     
            reflected_this_frame = true;
        }


        if (reflected_this_frame) {
            ball_boost_timer = BALL_BOOST_DURATION_FRAMES;
            current_ball_speed = INITIAL_BALL_SPEED * BALL_BOOST_FACTOR;
        }

        if (ball_boost_timer > 0) {
            ball_boost_timer--;
            if (ball_boost_timer == 0) {
                current_ball_speed = INITIAL_BALL_SPEED;     
            }
        }

        SDL_SetRenderDrawColor(renderer, 0xFF, 0xFF, 0xFF, 0xFF);   
        SDL_RenderClear(renderer);

        drawFilledCircle(renderer, static_cast<int>(ball_x), static_cast<int>(ball_y), BALL_RADIUS, 0xFF, 0x00, 0x00, 0xFF);   

        SDL_SetRenderDrawColor(renderer, 0x00, 0x00, 0xFF, 0xFF);
        SDL_RenderFillRect(renderer, &leftPaddle);

        SDL_SetRenderDrawColor(renderer, 0x00, 0xFF, 0x00, 0xFF);
        SDL_RenderFillRect(renderer, &rightPaddle);

        SDL_RenderPresent(renderer);
    }

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();

    return 0;
}